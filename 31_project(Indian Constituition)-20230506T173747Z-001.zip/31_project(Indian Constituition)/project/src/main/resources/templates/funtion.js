jQuery(document).ready(function () {
		jQuery(".container-wrap").append(
			"<ul class='circles'><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>"
		);
	});